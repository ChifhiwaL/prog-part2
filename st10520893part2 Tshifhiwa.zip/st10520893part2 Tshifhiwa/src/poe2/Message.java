package poe2;

import java.util.ArrayList; 
import java.util.Random; 
import java.util.Scanner; 
import java.nio.file.Files; 
import java.nio.file.Paths; 
import java.io.BufferedWriter; 
import java.io.IOException; 

public class Message {
    private String id; 
    private String content; 
    private String recipient; 
    private String timestamp; 
    private String messageHash; 
    private static ArrayList<Message> sentMessages = new ArrayList<>(); 
    private static int totalMessagesSent = 0; 

    // Main constructor
    public Message(String content, String recipient, String timestamp, String recipientCell) { 
        this.id = generateMessageId(); 
        this.content = content; 
        this.recipient = recipient; 
        this.timestamp = timestamp; 
        this.messageHash = createMessageHash(); 
    }

    // Generate a 10-digit random message ID 
    private String generateMessageId() { 
        Random random = new Random(); 
        long idLong = (long) (random.nextDouble() * 9000000000L) + 1000000000L; 
        return String.valueOf(idLong); 
    } 

    // Check if message ID is exactly 10 characters 
    public boolean checkMessageID() { 
        return id != null && id.length() == 10; 
    } 

    // Check if recipient cell number is exactly 12 characters and starts with +27 
    public int checkRecipientCell() { 
        if (recipient == null || recipient.length() != 12 || !recipient.startsWith("+27")) { 
            return 0; // Invalid (changed from -1 to match test expectations)
        } 
        return 1; // Valid (changed from 0 to match test expectations)
    } 

    // Create and return the Message Hash 
    public String createMessageHash() { 
        if (id == null || content == null) {
            return "";
        }
        
        String firstTwoNumbers = id.length() >= 2 ? id.substring(0, 2) : id; 
        String[] words = content.trim().split("\\s+"); 
        String firstWord = words.length > 0 ? words[0] : ""; 
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord; 
        
        this.messageHash = (firstTwoNumbers + ":" + firstWord.toUpperCase() + ":" + lastWord.toUpperCase()).trim();
        return this.messageHash; 
    } 

    // Allow user to choose to send, store, or disregard the message 
    public String sendMessage() { 
        Scanner scanner = new Scanner(System.in); 
        System.out.println("Choose an action:"); 
        System.out.println("1. Send Message"); 
        System.out.println("2. Disregard Message"); 
        System.out.println("3. Store Message to send later"); 
        System.out.print("Enter your choice (1-3): "); 
        int action = scanner.nextInt(); 
        scanner.nextLine(); // Consume newline 

        switch (action) { 
            case 1: 
                sentMessages.add(this); 
                totalMessagesSent++; 
                return "Message sent successfully."; 
            case 2: 
                return "Message disregarded."; 
            case 3: 
                sentMessages.add(this); 
                totalMessagesSent++; 
                return "Message stored for later sending."; 
            default: 
                return "Invalid choice. Message disregarded."; 
        } 
    } 

    // Return a list of all messages sent while the program is running 
    public static ArrayList<Message> printMessages() { 
        return new ArrayList<>(sentMessages); 
    } 

    // Return the total number of messages sent 
    public static int returnTotalMessages() { 
        return totalMessagesSent; 
    } 

    // Static accessors for sentMessages and totalMessagesSent 
    public static ArrayList<Message> getSentMessages() { 
        return sentMessages; 
    } 

    public static void incrementTotalMessagesSent() { 
        totalMessagesSent++; 
    } 

    // Custom method to store messages in JSON 
    public static void storeMessage(ArrayList<Message> messages, ArrayList<Message> pendingMessages) {
        // Handle null inputs gracefully
        if (messages == null) {
            messages = new ArrayList<>();
        }
        if (pendingMessages == null) {
            pendingMessages = new ArrayList<>();
        }
        
        StringBuilder jsonContent = new StringBuilder(); 
        jsonContent.append("{\n"); 
        jsonContent.append("  \"sentMessages\": [\n"); 
        
        for (int i = 0; i < messages.size(); i++) { 
            Message msg = messages.get(i); 
            jsonContent.append("    {\n"); 
            jsonContent.append("      \"id\": \"").append(msg.id).append("\",\n"); 
            jsonContent.append("      \"content\": \"").append(msg.content).append("\",\n"); 
            jsonContent.append("      \"recipient\": \"").append(msg.recipient).append("\",\n"); 
            jsonContent.append("      \"timestamp\": \"").append(msg.timestamp).append("\",\n"); 
            jsonContent.append("      \"messageHash\": \"").append(msg.messageHash).append("\"\n"); 
            jsonContent.append("    }").append(i < messages.size() - 1 ? "," : "").append("\n"); 
        } 
        
        jsonContent.append("  ],\n"); 
        jsonContent.append("  \"pendingMessages\": [\n"); 
        
        for (int i = 0; i < pendingMessages.size(); i++) { 
            Message msg = pendingMessages.get(i); 
            jsonContent.append("    {\n"); 
            jsonContent.append("      \"id\": \"").append(msg.id).append("\",\n"); 
            jsonContent.append("      \"content\": \"").append(msg.content).append("\",\n"); 
            jsonContent.append("      \"recipient\": \"").append(msg.recipient).append("\",\n"); 
            jsonContent.append("      \"timestamp\": \"").append(msg.timestamp).append("\",\n"); 
            jsonContent.append("      \"messageHash\": \"").append(msg.messageHash).append("\"\n"); 
            jsonContent.append("    }").append(i < pendingMessages.size() - 1 ? "," : "").append("\n"); 
        } 
        
        jsonContent.append("  ]\n"); 
        jsonContent.append("}"); 

        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get("messages.json"))) { 
            writer.write(jsonContent.toString()); 
            System.out.println("Messages stored in messages.json."); 
        } catch (IOException e) { 
            System.out.println("Error writing to JSON file: " + e.getMessage()); 
        } 
    } 

    // Getters for private fields 
    public String getId() { 
        return id; 
    } 
    
    public String getContent() { 
        return content; 
    } 
    
    public String getRecipient() { 
        return recipient; 
    } 
    
    public String getTimestamp() { 
        return timestamp; 
    } 
    
    public String getMessageHash() { 
        return messageHash; 
    } 
}