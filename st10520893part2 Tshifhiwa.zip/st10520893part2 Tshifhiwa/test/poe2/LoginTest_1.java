package poe2;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class LoginTest_1 {

    private Login Login;

    @Before
    public void setUp() {
        Login = new Login();
    }

    @Test
    public void testCheckUserName_Valid() {
        assertTrue(Login.checkUserName("abc_"));
    }

    @Test
    public void testCheckUserName_Invalid_NoUnderscore() {
        assertFalse(Login.checkUserName("abc"));
    }

    @Test
    public void testCheckUserName_Invalid_TooLong() {
        assertFalse(Login.checkUserName("abc_def"));
    }

    @Test
    public void testCheckPasswordComplexity_Valid() {
        assertTrue(Login.checkPasswordComplexity("Abcdef1!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_Short() {
        assertFalse(Login.checkPasswordComplexity("Ab1!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_NoUppercase() {
        assertFalse(Login.checkPasswordComplexity("abcdef1!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_NoNumber() {
        assertFalse(Login.checkPasswordComplexity("Abcdefg!"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_NoSpecialChar() {
        assertFalse(Login.checkPasswordComplexity("Abcdefg1"));
    }

    @Test
    public void testRegisterUser_Valid() {
        String result = Login.registerUser("Password1!", "usr_", "John", "Doe");
        assertTrue(result.contains("Username successfully captured"));
        assertTrue(result.contains("Password successfully captured"));
    }

    @Test
    public void testRegisterUser_Invalid() {
        String result = Login.registerUser("pass", "user123", "Jane", "Smith");
        assertTrue(result.contains("Username is not correctly formatted"));
        assertTrue(result.contains("Password is not correctly formatted"));
    }
}