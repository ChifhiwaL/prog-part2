package poe2;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Unit tests for Message class
 * @author RC_Student_Lab
 */
public class MessageTest {
    
    private Message validMessage;
    private Message invalidIdMessage;
    private Message invalidCellMessage;
    
    public MessageTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        // Create test messages - adjust constructor parameters based on your Message class
        validMessage = new Message("MSG001", "Hello, this is a test message", "John Doe", "0821234567");
        invalidIdMessage = new Message("INVALID", "Test content", "Jane Smith", "0829876543");
        invalidCellMessage = new Message("MSG002", "Another message", "Bob Jones", "123");
    }
    
    @After
    public void tearDown() {
        validMessage = null;
        invalidIdMessage = null;
        invalidCellMessage = null;
    }

    /**
     * Test of checkMessageID method, of class Message.
     */
    @Test
    public void testCheckMessageID() {
        System.out.println("checkMessageID");
        boolean result = validMessage.checkMessageID();
        assertTrue("Valid message ID should return true", result);
        
        boolean invalidResult = invalidIdMessage.checkMessageID();
        assertFalse("Invalid message ID should return false", invalidResult);
    }

    /**
     * Test of checkRecipientCell method, of class Message.
     */
    @Test
    public void testCheckRecipientCell() {
        System.out.println("checkRecipientCell");
        int result = validMessage.checkRecipientCell();
        assertEquals("Valid cell number should return 1", 1, result);
        
        int invalidResult = invalidCellMessage.checkRecipientCell();
        assertEquals("Invalid cell number should return 0", 0, invalidResult);
    }

    /**
     * Test of createMessageHash method, of class Message.
     */
    @Test
    public void testCreateMessageHash() {
        System.out.println("createMessageHash");
        String result = validMessage.createMessageHash();
        assertNotNull("Message hash should not be null", result);
        assertFalse("Message hash should not be empty", result.isEmpty());
    }

    /**
     * Test of sendMessage method, of class Message.
     */
    @Test
    public void testSendMessage() {
        System.out.println("sendMessage");
        String result = validMessage.sendMessage();
        assertNotNull("Send result should not be null", result);
        assertTrue("Result should contain relevant message", 
                   result.length() > 0);
    }

    /**
     * Test of printMessages method, of class Message.
     */
    @Test
    public void testPrintMessages() {
        System.out.println("printMessages");
        ArrayList<Message> result = Message.printMessages();
        assertNotNull("printMessages should return a list, not null", result);
    }

    /**
     * Test of returnTotalMessages method, of class Message.
     */
    @Test
    public void testReturnTotalMessages() {
        System.out.println("returnTotalMessages");
        int result = Message.returnTotalMessages();
        assertTrue("Total messages should be non-negative", result >= 0);
    }

    /**
     * Test of getSentMessages method, of class Message.
     */
    @Test
    public void testGetSentMessages() {
        System.out.println("getSentMessages");
        ArrayList<Message> result = Message.getSentMessages();
        assertNotNull("getSentMessages should return a list, not null", result);
    }

    /**
     * Test of incrementTotalMessagesSent method, of class Message.
     */
    @Test
    public void testIncrementTotalMessagesSent() {
        System.out.println("incrementTotalMessagesSent");
        int beforeCount = Message.returnTotalMessages();
        Message.incrementTotalMessagesSent();
        int afterCount = Message.returnTotalMessages();
        assertEquals("Message count should increase by 1", beforeCount + 1, afterCount);
    }

    /**
     * Test of storeMessage method, of class Message.
     */
    @Test
    public void testStoreMessage() {
        System.out.println("storeMessage");
        ArrayList<Message> messages = new ArrayList<>();
        ArrayList<Message> pendingMessages = new ArrayList<>();
        
        // This method should not throw an exception
        try {
            Message.storeMessage(messages, pendingMessages);
            assertTrue("Method executed without exception", true);
        } catch (Exception e) {
            fail("storeMessage should not throw exception: " + e.getMessage());
        }
    }

    /**
     * Test of getId method, of class Message.
     */
    @Test
    public void testGetId() {
        System.out.println("getId");
        String result = validMessage.getId();
        assertNotNull("ID should not be null", result);
        assertEquals("Should return correct ID", "MSG001", result);
    }

    /**
     * Test of getContent method, of class Message.
     */
    @Test
    public void testGetContent() {
        System.out.println("getContent");
        String result = validMessage.getContent();
        assertNotNull("Content should not be null", result);
        assertEquals("Should return correct content", "Hello, this is a test message", result);
    }

    /**
     * Test of getRecipient method, of class Message.
     */
    @Test
    public void testGetRecipient() {
        System.out.println("getRecipient");
        String result = validMessage.getRecipient();
        assertNotNull("Recipient should not be null", result);
        assertEquals("Should return correct recipient", "John Doe", result);
    }

    /**
     * Test of getTimestamp method, of class Message.
     */
    @Test
    public void testGetTimestamp() {
        System.out.println("getTimestamp");
        String result = validMessage.getTimestamp();
        assertNotNull("Timestamp should not be null", result);
        assertFalse("Timestamp should not be empty", result.isEmpty());
    }

    /**
     * Test of getMessageHash method, of class Message.
     */
    @Test
    public void testGetMessageHash() {
        System.out.println("getMessageHash");
        // First create the hash
        validMessage.createMessageHash();
        String result = validMessage.getMessageHash();
        assertNotNull("Message hash should not be null", result);
        assertFalse("Message hash should not be empty", result.isEmpty());
    }
}